import { Component } from '@angular/core';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-leave-request',
  templateUrl: './leave-request.component.html',
  styleUrls: ['./leave-request.component.scss']
})
export class LeaveRequestComponent {
  leaveRequest: any = {
    leaveReason: '',
    startDate: '',
    endDate: '',
    documentUrl: ''
  };

  constructor(private apiService: ApiService, private router: Router) {}

  submitLeaveRequest(): void {
    // Ensure startDate and endDate are in ISO format
    this.leaveRequest.startDate = new Date(this.leaveRequest.startDate).toISOString();
    this.leaveRequest.endDate = new Date(this.leaveRequest.endDate).toISOString();

    this.apiService.createLeaveRequest(this.leaveRequest).subscribe(
      (response) => {
        console.log('Leave request created successfully:', response);
        this.router.navigate(['/employee']);
      },
      (error) => {
        console.error('Error creating leave request:', error);
        // Handle error (e.g., display error message to user)
      }
    );
  }
}
