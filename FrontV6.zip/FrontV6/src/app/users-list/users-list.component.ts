import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { User } from '../User.model';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss']
})
export class UsersListComponent implements OnInit {
  userProfile: any;

  users: User[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.fetchUsers();
  }

  fetchUsers(): void {
    this.apiService.getAllUsers().subscribe(
      users => {
        this.users = users;
      },
      error => {
        console.error('Error fetching users:', error);
      }
    );
  }

  fetchUserProfile(userId: number): void {
    this.apiService.getUserProfile1(userId).subscribe(
      userProfile => {
        this.userProfile = userProfile;
      },
      error => {
        console.error('Error fetching user profile:', error);
      }
    );
  }
}
