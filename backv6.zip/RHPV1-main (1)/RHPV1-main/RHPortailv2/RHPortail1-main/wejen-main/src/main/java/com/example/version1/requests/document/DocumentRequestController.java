package com.example.version1.requests.document;

import com.example.version1.users.User;
import com.example.version1.users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import javax.naming.AuthenticationException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/requests/document")
public class DocumentRequestController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DocumentRequestService documentRequestService;

    @PostMapping("/send-req")
    public ResponseEntity<DocumentRequest> createDocumentRequest(@RequestBody DocumentRequest request,
                                                                 Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof Jwt)) {
            throw new AuthenticationException("Authentication is missing or invalid for this request");
        }

        Jwt jwtToken = (Jwt) authentication.getPrincipal();
        String userEmail = jwtToken.getClaim("sub");

        Optional<User> userOptional = userRepository.findByEmail(userEmail);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("User not found");
        }
        User user = userOptional.get();
        Long userId = user.getId();

        request.setUserId(userId);

        // Set default status to 'pending' if status is not provided
        if (request.getStatus() == null || request.getStatus().isEmpty()) {
            request.setStatus("pending");
        }

        DocumentRequest createdRequest = documentRequestService.createDocumentRequest(request,userId);
        return new ResponseEntity<>(createdRequest, HttpStatus.CREATED);
    }
    // DocumentRequestController.java
    @PutMapping("/{id}/status")
    public ResponseEntity<DocumentRequest> updateDocumentRequestStatusAndResponse(@PathVariable Long id,
                                                                                  @RequestParam String newStatus,
                                                                                  @RequestParam(required = false) String response) {
        DocumentRequest updatedRequest = documentRequestService.updateDocumentRequestStatusAndResponse(id, newStatus, response);
        return new ResponseEntity<>(updatedRequest, HttpStatus.OK);
    }
    @GetMapping("/my-document-requests")
    public ResponseEntity<List<DocumentRequest>> getMyDocumentRequests(Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new AuthenticationException("User not authenticated");
        }

        Jwt jwtToken = (Jwt) authentication.getPrincipal();
        String userEmail = jwtToken.getClaim("sub");

        Optional<User> userOptional = userRepository.findByEmail(userEmail);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("User not found");
        }
        User user = userOptional.get();

        Long userId = user.getId();

        List<DocumentRequest> userDocumentRequests = documentRequestService.getDocumentRequestsByUserId(userId);

        return new ResponseEntity<>(userDocumentRequests, HttpStatus.OK);
    }

    // DocumentRequestService.java


}