package com.example.version1.requests.Leave;

import com.example.version1.requests.Leave.LeaveRequest;
import com.example.version1.requests.Leave.LeaveRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeaveRequestService {

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;

    public LeaveRequest createLeaveRequest(LeaveRequest request , Long userId) {
        return leaveRequestRepository.save(request);
    }
    public List<LeaveRequest> getAllLeaveRequests() {
        return leaveRequestRepository.findAll();
    }
    public List<LeaveRequest> getPendingLeaveRequests() {
        return leaveRequestRepository.findByStatus("pending");
    }

   /* public LeaveRequest updateLeaveRequestStatusAndResponse(Long id, String newStatus, String response) {
        LeaveRequest request = leaveRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Leave request not found with ID: " + id));

        request.setStatus(newStatus);
        request.setResponse(response);

        return leaveRequestRepository.save(request);
    }*/

    public int countPendingLeaveRequests() {
        return leaveRequestRepository.countByStatus("pending");

    }

     public LeaveRequest approveByHR(Long id , String response) {
        LeaveRequest leaveRequest = leaveRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Leave request not found"));
        leaveRequest.setStatus("HR_APPROVED");

        return leaveRequestRepository.save(leaveRequest);
    }

    public LeaveRequest denyByHR(Long id , String response) {
        LeaveRequest leaveRequest = leaveRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Leave request not found"));
        leaveRequest.setStatus("HR_DENIED");
        return leaveRequestRepository.save(leaveRequest);
    }

    public LeaveRequest approveOrDenyByAdmin(Long id, boolean isApproved, String response) {
        LeaveRequest leaveRequest = leaveRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Leave request not found"));
        if (isApproved) {
            leaveRequest.setStatus("ADMIN_APPROVED");
        } else {
            leaveRequest.setStatus("ADMIN_DENIED");
        }
        leaveRequest.setResponse(response);
        return leaveRequestRepository.save(leaveRequest);
    }
    public List<LeaveRequest> getLeaveRequestsByUserId(Long userId) {
        return leaveRequestRepository.findByUserId(userId);
    }


    public List<LeaveRequest> getHRApprovedRequestsPendingAdmin() {
        return leaveRequestRepository.findByStatus("HR_APPROVED");
    }}