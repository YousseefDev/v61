package com.example.version1.requests.personal;

import com.example.version1.users.User;
import com.example.version1.users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import javax.naming.AuthenticationException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/requests/personal")
public class PersonalSituationRequestController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PersonalSituationRequestService personalSituationRequestService;

    @PostMapping("/send-req")
    public ResponseEntity<PersonalSituationRequest> createPersonalSituationRequest(@RequestBody PersonalSituationRequest request, Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof Jwt)) {
            throw new AuthenticationException("Authentication is missing or invalid for this request");
        }

        Jwt jwtToken = (Jwt) authentication.getPrincipal();
        String userEmail = jwtToken.getClaim("sub");

        Optional<User> userOptional = userRepository.findByEmail(userEmail);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("User not found");
        }
        User user = userOptional.get();
        Long userId = user.getId();

        request.setUserId(userId);


        PersonalSituationRequest createdRequest = personalSituationRequestService.createPersonalSituationRequest(request, userId);
        return new ResponseEntity<>(createdRequest, HttpStatus.CREATED);
    }
    @PutMapping("/{id}/status")
    public ResponseEntity<PersonalSituationRequest> updatePersonalSituationRequestStatusAndResponse(@PathVariable Long id,
                                                                                                    @RequestParam String newStatus,
                                                                                                    @RequestParam(required = false) String response) {
        PersonalSituationRequest updatedRequest = personalSituationRequestService.updatePersonalSituationRequestStatusAndResponse(id, newStatus, response);
        return new ResponseEntity<>(updatedRequest, HttpStatus.OK);
    }
    @GetMapping("/my-personal-situation-requests")
    public ResponseEntity<List<PersonalSituationRequest>> getMyPersonalSituationRequests(Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new AuthenticationException("User not authenticated");
        }

        Jwt jwtToken = (Jwt) authentication.getPrincipal();
        String userEmail = jwtToken.getClaim("sub");

        Optional<User> userOptional = userRepository.findByEmail(userEmail);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("User not found");
        }
        User user = userOptional.get();

        Long userId = user.getId();

        List<PersonalSituationRequest> userPersonalSituationRequests = personalSituationRequestService.getPersonalSituationRequestsByUserId(userId);

        return new ResponseEntity<>(userPersonalSituationRequests, HttpStatus.OK);
    }


}
